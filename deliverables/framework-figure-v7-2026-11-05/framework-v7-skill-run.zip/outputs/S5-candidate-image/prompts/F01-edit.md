# F01 targeted image_gen edit

Input: inputs/generation-history/F01-draft.png

Preserve overall figure. Correct the support TRAINING encoder to Frozen CLIP ViT-L/14 blocks1–24 + prompts; cache and query-prototype encoders remain1–12. Delete ordinary CE→P* arrow and P* state to CE's right. Place Fitted prompts P* next to upper P parameter state; CE produces no prompt forward output. Reverse dashed orange gradient loop: START at CE, left around lower training corridor, up, arrowhead END at P; no dashed arrowhead into CE. Preserve logits→CE and y→CE. Other panels unchanged.
