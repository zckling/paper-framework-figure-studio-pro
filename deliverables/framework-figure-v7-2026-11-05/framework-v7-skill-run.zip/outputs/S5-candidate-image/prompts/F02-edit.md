# F02 targeted image_gen edit

Input: inputs/generation-history/F02-draft.png

Preserve all panels and formulas. Delete cache→training Cosine logits arrow and divider→prototype floating vertical arrow. Name top stored cache C; repeat same C state as a local port above the prototype module with one short downward arrow; no long cross-panel bus. Add separate orange P→training encoder insertion arrow, preserve CE→P feedback. Move lower-query load P* parameter pair off the black query-image input path and use separate short load arrow, keeping x directly connected to encoder. No image enters P*. Other layout unchanged.
