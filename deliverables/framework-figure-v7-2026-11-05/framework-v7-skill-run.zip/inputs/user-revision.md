当前用户逐项修改要求（本轮执行规格摘要）
保留support准备/query推断分离、两独立分支与概率融合，重画prompt fitting、prototype mixing、prompt replacement。
训练：标题Support-set adaptation · once per support set；S=K real+K fake总2K；support图像和可训练P进冻结CLIP；特征与固定t0/t1算native logits；logits与y进CE；CE反馈至P，Update prompts only；P*是已训练状态，非CE数据输出。
编码：同一ViT-L/14预训练权重但独立forward；原型取blocks1–12的1024维CLS（ln_post/projection前），提示走blocks1–24后得到768维投影特征。两encoder同宽立边轻圆角，不共享前12块激活。
b：每类softmax→weighted sum m_c(q)→0.5μ_c+0.5m_c(q)→L2 normalize；m混合前不得再次归一化；去掉无标签几何框，q改特征条；总览抽象不重复底部链。
c：四段1–6/7–12/13–18/19–24；保留CLS与image token状态，丢弃stage输出promptstates并叉号，插入下一组已学P_s*；至少一处画token序列；冻结按组标一次；末尾CLSreadout/projection；四组联合优化8192参数，推理P*固定。
连线：cache紧邻prototype，P*采用明确同名状态端口避免跨支路长线；两query行列对齐；用(a)overview/(b)prototype mixing/(c)prompt replacement和detailin(b)/(c)对应，不画数据箭头到放大面板。
评分：Cosine similarity difference；CE用原生CLIP尺度S=exp(logit_scale)，推理固定15；概率记号p_p(q)、p_v(x)，融合p(x)=[p_p(q(x))+p_v(x)]/2；只保留Probability average盒内公式，不重复0.5和加号。
配色：real蓝/fake绿/prompt橙，面板统一极浅灰；图例底部一行；冻结少画；每类两张照片+省略号；cache类符号少而大；减冗余文字检查论文宽度。
本轮明确要求“使用skill来画这个技术框架图”。继承此前明确要求的可编辑Visio交付和上传指定GitHub仓库授权。
