"""Support-only fit and query-only score engine for visual prompt candidates.

No method in score() reads labels, trains parameters, constructs query statistics,
or inherits any state from a previous query. Saved payloads exclude CLIP weights.
"""
from __future__ import annotations

import hashlib
import importlib.util
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
from torchvision.transforms import InterpolationMode

from clip_text_prompt import encode_text_causal
from visual_prompt_candidates import (EXPECTED_PARAMETERS, VARIANTS, VisualCandidate,
                                      frozen_final_feature, image_tokens,
                                      spherical_patch_initialization)


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_clip_library(root):
    # Private import namespace prevents the CNNSpot/CLIP same-name networks
    # conflict, without deleting or replacing any foreign sys.modules entry.
    package_root = Path(root) / "networks" / "clip"
    namespace = "_sealed_visual_candidates_clip_" + hashlib.sha256(str(package_root).encode()).hexdigest()[:12]
    if namespace not in sys.modules:
        spec = importlib.util.spec_from_file_location(namespace, package_root / "__init__.py",
                                                     submodule_search_locations=[str(package_root)])
        if spec is None or spec.loader is None:
            raise ImportError("Cannot load private CLIP library")
        module = importlib.util.module_from_spec(spec)
        sys.modules[namespace] = module
        try:
            spec.loader.exec_module(module)
        except BaseException:
            sys.modules.pop(namespace, None)
            raise
    return sys.modules[namespace]


def _convert_image_to_rgb(image):
    """Importable equivalent of CLIP's RGB converter for Windows workers."""
    return image.convert("RGB")


def _spawn_safe_preprocess(preprocess):
    """Keep official transforms exact while removing the private-package callable.

    Dynamic CLIP loading safely isolates model imports, but Windows spawn cannot
    import a runtime-created package when unpickling its RGB conversion function.
    The replacement has the exact same operation in this normal importable module.
    """
    sequence = []
    replaced = 0
    for transform in preprocess.transforms:
        if (getattr(transform, "__name__", None) == "_convert_image_to_rgb"
                and getattr(transform, "__module__", "").startswith("_sealed_visual_candidates_clip_")):
            sequence.append(_convert_image_to_rgb)
            replaced += 1
        else:
            sequence.append(transform)
    if replaced != 1:
        raise ValueError(f"Expected exactly one private CLIP RGB conversion, found {replaced}")
    return transforms.Compose(sequence)


def _seed_all(seed):
    random.seed(seed)
    np.random.seed(seed % (2**32))
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def _components(name, value):
    if name in ("prompt_stages", "prompt_bases"):
        return {f"{name}[{index}]": component for index, component in enumerate(value)}
    return {name: value}


class _RouteStatistics:
    """Read-only distribution diagnostics; never used to fit or choose anything."""
    def __init__(self):
        self.count = self.saturated = 0
        self.sum = self.sumsq = 0.0
        self.minimum, self.maximum = float("inf"), float("-inf")

    def add(self, values):
        if values is None:
            return
        data = values.detach().double().cpu().numpy()
        self.count += data.size
        self.sum += float(data.sum())
        self.sumsq += float((data*data).sum())
        self.minimum = min(self.minimum, float(data.min()))
        self.maximum = max(self.maximum, float(data.max()))
        self.saturated += int(((data < 0.05) | (data > 0.95)).sum())

    def result(self):
        if not self.count:
            return None
        mean = self.sum / self.count
        return {"count": self.count, "min": self.minimum, "max": self.maximum,
                "mean": mean, "std_population": max(0.0, self.sumsq/self.count-mean*mean)**0.5,
                "saturated_fraction_below_0.05_or_above_0.95": self.saturated/self.count,
                "diagnostic_only_no_fit_or_selection": True}


class _QueryImages(Dataset):
    def __init__(self, root, rows, transform):
        self.root, self.rows, self.transform = root, rows, transform

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        return _read(self.root, self.rows[index], self.transform)


def _read(root, row, transform):
    # The row's label is deliberately not consulted for image loading.
    path = root / row["path"]
    if not path.is_file() or ("size" in row and path.stat().st_size != int(row["size"])):
        raise ValueError(f"Missing or size-changed image: {row['path']}")
    try:
        with Image.open(path) as image:
            return transform(image.convert("RGB"))
    except Exception as exc:
        raise RuntimeError(f"Image decoding failed: {row['path']}") from exc


class Engine:
    def __init__(self, cfg):
        self.cfg = dict(cfg)
        if not torch.cuda.is_available():
            raise RuntimeError("Visual candidate engine requires the locked CUDA device")
        if int(cfg.get("batch_size", 1)) != 1 or int(cfg.get("epochs", 20)) != 20:
            raise ValueError("Locked training requires batch1 and 20 final epochs")
        if float(cfg.get("learning_rate", 0.0002)) != 0.0002:
            raise ValueError("Locked Adam learning rate changed")
        self.device = torch.device("cuda")
        self.root = Path(cfg["dataset_root"])
        self.checkpoint_sha = _sha256(cfg["checkpoint"])
        if cfg.get("checkpoint_sha256") and cfg["checkpoint_sha256"] != self.checkpoint_sha:
            raise ValueError("CLIP checkpoint SHA mismatch")
        library = _load_clip_library(cfg["clip_code_root"])
        self.clip, self.preprocess = library.load(cfg["checkpoint"], device="cuda", jit=False)
        self.preprocess = _spawn_safe_preprocess(self.preprocess)
        self.clip.eval().requires_grad_(False)
        self.clip.visual.input_resolution = int(self.clip.visual.input_resolution)
        if self.clip.visual.input_resolution != 224:
            raise ValueError("Expected ViT-L/14 at 224 resolution")
        ids = library.tokenize(cfg["class_descriptions"]).to(self.device)
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.float16):
            embedded = self.clip.token_embedding(ids).to(self.clip.dtype)
            self.fixed_text = encode_text_causal(self.clip, ids, embedded).detach()
        if self.fixed_text.shape != (2, 768):
            raise ValueError("Expected two fixed 768-dimensional class text vectors")
        self.train_transform = transforms.Compose([
            transforms.RandomResizedCrop(224, scale=(0.08, 1.0), interpolation=InterpolationMode.BICUBIC),
            transforms.RandomHorizontalFlip(0.5), *self.preprocess.transforms[-2:],
        ])
        torch.backends.cudnn.benchmark = False
        self.candidate = None
        self.loaded_payload = None
        self.last_score_info = None

    def _construct(self, variant, seed, k):
        training_seed = int(self.cfg.get("training_seed_base", 314159)) + int(seed)*100 + int(k)
        _seed_all(training_seed)
        # All equal-dimensional heads receive exactly the same initialization,
        # regardless of whether visual prompt parameters are also present.
        head_seed = training_seed + 271828
        candidate = VisualCandidate(self.clip, variant, init_seed=training_seed,
                                    head_seed=head_seed,
                                    staged_layers=self.cfg.get("staged_layers", [1, 7, 13, 19])).to(self.device)
        for name, parameter in candidate.trainable_named_parameters().items():
            if parameter.dtype != torch.float32:
                raise ValueError(f"Learnable parameter is not FP32: {name}")
        return candidate, training_seed, head_seed

    def _initialize(self, candidate, support, training_seed):
        variant = candidate.variant
        if variant == "patchinit8":
            patches = []
            with torch.no_grad(), torch.autocast("cuda", dtype=torch.float16):
                for row in support:
                    image = _read(self.root, row, self.preprocess).unsqueeze(0).to(self.device)
                    patches.append(image_tokens(self.clip, image)[0, 1:].float().cpu())
            values, initialization = spherical_patch_initialization(
                torch.cat(patches), seed=training_seed,
                iterations=int(self.cfg.get("patch_init_cluster_iterations", 20)), target_norm=0.64)
            with torch.no_grad():
                candidate.prompt.copy_(values.to(self.device))
            return initialization
        if variant == "randomnorm8":
            with torch.no_grad():
                candidate.prompt.copy_(F.normalize(candidate.prompt, dim=-1) * 0.64)
            return {"rule": "same_random_prompt_directions_as_text8_each_token_norm_0.64",
                    "target_token_norm": 0.64, "query_images_used": 0}
        return {"rule": "normal_mean0_std0.02_prompt_or_standard_torch_linear_head",
                "query_images_used": 0}

    @staticmethod
    def _validate_support(support, k):
        if len(support) != 2*k or sorted(int(r["label"]) for r in support) != [0]*k + [1]*k:
            raise ValueError("Support must contain exactly K real plus K fake")
        if len({r["path"] for r in support}) != 2*k:
            raise ValueError("Duplicate support path")
        if any(r.get("split", "train") != "train" for r in support):
            raise ValueError("Support training can only read train split")

    def _fit(self, variant, support, k, seed, *, preflight=False, progress_callback=None,
             diagnostic_image=None):
        self._validate_support(support, k)
        if variant not in VARIANTS:
            raise ValueError(variant)
        started = time.perf_counter()
        candidate, training_seed, head_seed = self._construct(variant, seed, k)
        self.candidate = candidate
        initialization = self._initialize(candidate, support, training_seed)
        before = candidate.learnable_state()
        diagnostic_before = None
        if diagnostic_image is not None:
            candidate.eval()
            with torch.inference_mode(), torch.autocast("cuda", dtype=torch.float16):
                before_logits, before_feature = candidate(diagnostic_image, self.fixed_text)
                diagnostic_before = (before_logits.detach().float().clone(),
                                     before_feature.detach().float().clone())
        params = list(candidate.trainable_named_parameters().values())
        optimizer = torch.optim.Adam(params, lr=float(self.cfg.get("learning_rate", 0.0002)), weight_decay=0.0)
        scaler = torch.amp.GradScaler("cuda", init_scale=float(self.cfg.get("gradient_scaler_initial_scale", 1.0)))
        order_generator = torch.Generator(device="cpu").manual_seed(training_seed)
        _seed_all(training_seed + 999)
        candidate.train()
        epochs = 1 if preflight else int(self.cfg.get("epochs", 20))
        steps = 0
        optimizer_steps = 0
        amp_skipped_steps = 0
        losses = []
        ce_values = []
        anchor_values = []
        grad_max = {name: 0.0 for name in candidate.trainable_named_parameters()}
        component_grad_max = {part_name: 0.0
                              for name, parameter in candidate.trainable_named_parameters().items()
                              for part_name in _components(name, parameter)}
        route_statistics = _RouteStatistics()
        torch.cuda.reset_peak_memory_stats()
        for epoch in range(epochs):
            indices = torch.randperm(len(support), generator=order_generator).tolist()
            if preflight:
                # Two distinct class supports; no query reads or metric selection.
                indices = [next(i for i, r in enumerate(support) if int(r["label"]) == y) for y in (0, 1)]
            for position in indices:
                row = support[position]
                image = _read(self.root, row, self.train_transform).unsqueeze(0).to(self.device)
                label = torch.tensor([int(row["label"])], device=self.device)
                optimizer.zero_grad(set_to_none=True)
                with torch.autocast("cuda", dtype=torch.float16):
                    logits, feature = candidate(image, self.fixed_text)
                    if candidate.variant == "conditional4":
                        route_statistics.add(candidate.last_route)
                    ce = F.cross_entropy(logits.float(), label)
                    if variant == "anchor8":
                        with torch.no_grad():
                            teacher = frozen_final_feature(self.clip, image)
                        anchor = (1 - (feature.float() * teacher.float()).sum(dim=-1)).mean()
                        loss = ce + float(self.cfg.get("anchor_lambda", 0.1)) * anchor
                    else:
                        anchor = ce.new_zeros(())
                        loss = ce
                if not torch.isfinite(loss):
                    raise RuntimeError("Nonfinite support training loss")
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                for name, parameter in candidate.trainable_named_parameters().items():
                    if parameter.grad is None or not torch.isfinite(parameter.grad).all():
                        raise RuntimeError(f"Missing/nonfinite learnable gradient: {name}")
                    grad_max[name] = max(grad_max[name], float(parameter.grad.float().norm()))
                    for component_name, value in _components(name, parameter.grad).items():
                        component_grad_max[component_name] = max(component_grad_max[component_name], float(value.float().norm()))
                if any(p.grad is not None for p in self.clip.parameters()):
                    raise RuntimeError("Frozen CLIP received a gradient")
                scale_before = float(scaler.get_scale())
                scaler.step(optimizer)
                scaler.update()
                if float(scaler.get_scale()) < scale_before:
                    amp_skipped_steps += 1
                else:
                    optimizer_steps += 1
                steps += 1
                losses.append(float(loss.detach()))
                ce_values.append(float(ce.detach()))
                anchor_values.append(float(anchor.detach()))
            if progress_callback is not None:
                progress_callback({"stage": "support_training", "epoch_completed": epoch+1,
                                   "epochs": epochs, "steps": steps, "variant": variant,
                                   "support_seed": seed, "K": k, "query_images_read": 0,
                                   "elapsed_seconds": time.perf_counter()-started})
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - started
        final = candidate.learnable_state()
        deltas = {name: float((final[name] - before[name]).norm()) for name in before}
        component_deltas = {component_name: float(value.norm())
                            for name in before
                            for component_name, value in _components(name, final[name]-before[name]).items()}
        if preflight and (any(value <= 0 for value in component_grad_max.values())
                          or any(value <= 0 for value in component_deltas.values())):
            raise RuntimeError(f"A learnable branch did not update: gradients={grad_max}, deltas={deltas}")
        info = {
            "status": "support_gradient_preflight_no_metrics" if preflight else "final_epoch_support_training_complete",
            "variant": variant, "K": k, "support_seed": seed, "training_seed": training_seed,
            "head_seed": head_seed, "epochs": epochs, "steps": steps,
            "amp_optimizer_steps": optimizer_steps, "amp_skipped_steps": amp_skipped_steps,
            "expected_steps": 2 if preflight else 2*k*epochs,
            "trainable_parameters": candidate.trainable_parameter_count(),
            "training_seconds": elapsed, "peak_cuda_memory_bytes": torch.cuda.max_memory_allocated(),
            "loss_first": losses[0], "loss_last": losses[-1],
            "ce_first": ce_values[0], "ce_last": ce_values[-1],
            "anchor_first": anchor_values[0], "anchor_last": anchor_values[-1],
            "maximum_gradient_norms": grad_max, "parameter_delta_norms": deltas,
            "maximum_component_gradient_norms": component_grad_max,
            "component_parameter_delta_norms": component_deltas,
            "training_forward_route_statistics": route_statistics.result(),
            "prompt_delta": sum(value*value for name, value in deltas.items() if name.startswith("prompt"))**0.5,
            "initialization": initialization, "query_images_read": 0,
            "clip_frozen": True, "clip_eval": not self.clip.training,
        }
        if steps != info["expected_steps"]:
            raise RuntimeError("Unexpected support optimization step count")
        payload = {
            "schema_version": 1, "variant": variant, "state": final,
            "trainable_parameters": candidate.trainable_parameter_count(),
            "checkpoint_sha256": self.checkpoint_sha,
            "final_epoch": epochs, "steps": steps, "K": k, "support_seed": seed,
            "amp_optimizer_steps": optimizer_steps, "amp_skipped_steps": amp_skipped_steps,
            "training_seed": training_seed, "head_seed": head_seed,
            "support": [dict(row) for row in support], "initialization": initialization,
            "recipe": self.recipe(), "source": "support_only_no_cache_no_text_training_no_query_fit",
        }
        candidate.eval()
        self.loaded_payload = payload
        if diagnostic_before is not None:
            with torch.inference_mode(), torch.autocast("cuda", dtype=torch.float16):
                after_logits, after_feature = candidate(diagnostic_image, self.fixed_text)
                after_logits = after_logits.float()
                after_feature = after_feature.float()
            before_logits, before_feature = diagnostic_before
            cosine = F.cosine_similarity(before_feature, after_feature, dim=-1)
            before_margin = before_logits[:, 1] - before_logits[:, 0]
            after_margin = after_logits[:, 1] - after_logits[:, 0]
            # This bypasses the final-epoch load gate only for an in-memory
            # diagnostic clone. A preflight payload is never accepted by load().
            reloaded, _, _ = self._construct(variant, seed, k)
            reloaded.load_learnable_state(payload["state"])
            reloaded.eval()
            with torch.inference_mode(), torch.autocast("cuda", dtype=torch.float16):
                reload_logits, reload_feature = reloaded(diagnostic_image, self.fixed_text)
                reload_logits = reload_logits.float()
                reload_feature = reload_feature.float()
            reload_logits_error = float((after_logits - reload_logits).abs().max())
            reload_feature_error = float((after_feature - reload_feature).abs().max())
            if reload_logits_error != 0.0 or reload_feature_error != 0.0:
                raise RuntimeError(f"Learnable-state exact reload failed: logits={reload_logits_error}, feature={reload_feature_error}")
            diagnostic = {
                "input": "same_synthetic_image_before_and_after_two_support_updates",
                "query_images_read": 0, "feature_cosine_before_after": cosine.cpu().tolist(),
                "feature_cosine_drift_mean": float((1-cosine).mean()),
                "feature_max_abs_change": float((after_feature-before_feature).abs().max()),
                "raw_margin_before": before_margin.cpu().tolist(),
                "raw_margin_after": after_margin.cpu().tolist(),
                "raw_margin_max_abs_change": float((after_margin-before_margin).abs().max()),
                "logits_reload_max_abs": reload_logits_error,
                "feature_reload_max_abs": reload_feature_error,
                "reload_exact": True,
                "performance_improvement_required": False,
            }
            if not all(np.isfinite(value) for key, value in diagnostic.items()
                       if isinstance(value, float)):
                raise RuntimeError("Nonfinite synthetic preflight diagnostic")
            info["synthetic_before_after_and_reload"] = diagnostic
            del reloaded
        return payload, info

    def recipe(self):
        return {"optimizer": "Adam", "learning_rate": 0.0002, "weight_decay": 0.0,
                "epochs": 20, "batch_size": 1, "checkpoint_rule": "last_epoch_no_query_selection",
                "training_seed_base": int(self.cfg.get("training_seed_base", 314159)),
                "train_transform": "RRC224_scale_0.08_1_bicubic_flip0.5_CLIP_normalize",
                "query_transform": "official_CLIP_preprocess",
                "fixed_class_descriptions": list(self.cfg["class_descriptions"]),
                "anchor_lambda": float(self.cfg.get("anchor_lambda", 0.1)),
                "anchor_feature": "final_projected_normalized_same_augmented_support_tensor",
                "staged_layers": list(self.cfg.get("staged_layers", [1, 7, 13, 19])),
                "l12": "post_block12_pre_lnpost_pre_projection_normalized",
                "clspatch": "concat_normalized_CLS_and_normalized_image_patch_mean_div_sqrt2",
                "conditional_input": "detached_normalized_post_pos_lnpre_image_patch_mean",
                "raw_score": "fake_logit_minus_real_logit", "queryfit": 0}

    def fit(self, variant, support_rows, k, seed, progress_callback=None):
        return self._fit(variant, support_rows, int(k), int(seed), progress_callback=progress_callback)

    def load(self, payload):
        variant = payload["variant"]
        if variant not in VARIANTS or payload["checkpoint_sha256"] != self.checkpoint_sha:
            raise ValueError("Payload variant or checkpoint differs from the sealed input")
        if payload["recipe"] != self.recipe() or int(payload["final_epoch"]) != 20:
            raise ValueError("Payload recipe/final epoch differs from the sealed input")
        k, seed = int(payload["K"]), int(payload["support_seed"])
        self._validate_support(payload["support"], k)
        candidate, training_seed, head_seed = self._construct(variant, seed, k)
        if (payload["training_seed"] != training_seed or payload["head_seed"] != head_seed
                or payload["trainable_parameters"] != EXPECTED_PARAMETERS[variant]
                or payload["steps"] != 40*k):
            raise ValueError("Payload seed, trainable count, or final step count mismatch")
        candidate.load_learnable_state(payload["state"])
        candidate.eval()
        self.candidate = candidate
        self.loaded_payload = payload

    def score(self, query_rows, progress_callback=None):
        if self.candidate is None:
            raise RuntimeError("Fit or load a visual candidate before query scoring")
        candidate = self.candidate
        candidate.eval()
        loader = DataLoader(_QueryImages(self.root, query_rows, self.preprocess),
                            batch_size=int(self.cfg.get("inference_batch_size", 32)), shuffle=False,
                            num_workers=int(self.cfg.get("query_workers", 0)), pin_memory=True,
                            drop_last=False)
        scores = []
        count = 0
        route_statistics = _RouteStatistics()
        started = time.perf_counter()
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.float16):
            for images in loader:
                logits, _ = candidate(images.to(self.device, non_blocking=True), self.fixed_text)
                if candidate.variant == "conditional4":
                    route_statistics.add(candidate.last_route)
                margin = (logits[:, 1].float() - logits[:, 0].float()).cpu().numpy()
                if not np.isfinite(margin).all():
                    raise RuntimeError("Nonfinite query score")
                scores.append(margin.astype(np.float32, copy=False))
                count += len(margin)
                if progress_callback is not None:
                    progress_callback({"stage": "query_forward_only", "query_completed": count,
                                       "query_total": len(query_rows), "variant": candidate.variant,
                                       "elapsed_seconds": time.perf_counter()-started})
        self.last_score_info = {"variant": candidate.variant, "query_images": count,
                                "query_seconds": time.perf_counter()-started,
                                "query_route_statistics": route_statistics.result(),
                                "queryfit": 0, "query_labels_read": 0}
        return np.concatenate(scores).astype(np.float32, copy=False) if scores else np.empty(0, dtype=np.float32)

    def preflight(self, variant, support_rows, seed):
        k = len(support_rows) // 2
        self._validate_support(support_rows, k)
        # Synthetic parity, no query data. Fixed generator leaves crop RNG intact.
        generator = torch.Generator(device="cuda").manual_seed(718281)
        image = torch.randn(1, 3, 224, 224, generator=generator, device=self.device)
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.float16):
            original = F.normalize(self.clip.encode_image(image).float(), dim=-1)
            manual = frozen_final_feature(self.clip, image)
            error = float((original - manual).abs().max())
        if error > 1e-4:
            raise RuntimeError(f"Original CLIP image-forward parity failed: {error}")
        _, info = self._fit(variant, support_rows, k, int(seed), preflight=True,
                            diagnostic_image=image)
        info.update({"synthetic_final_forward_parity_max_abs": error,
                     "query_metrics_computed": False, "query_scores_saved": False,
                     "checkpoint_sha256": self.checkpoint_sha})
        return info
