"""UFD ProGAN-source V2 adapter, with no cache or target-side fitting.

The sealed staged2 architecture and support-training loop are imported without
modification. Importing this module, validating a payload, or inspecting recipe()
does not allocate CUDA memory. Only load_model() constructs the CUDA engine.

The runner owns manifest/Git gates, serialization and metrics. This module only
fits the exact ProGAN/train support, loads its final prompt state, and returns
two logits plus their softmax in the supplied query order. It never reads query
labels. Saved-state/source checks are provenance checks, not neural replay.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path, PurePosixPath

import numpy as np
import torch
from torch.utils.data import DataLoader

from visual_prompt_candidate_engine import Engine, _QueryImages


VARIANT = "staged2"
METHOD = "V2"
PARAMETER_SHAPES = {"prompt_stages": (4, 2, 1024)}
TRAINABLE_PARAMETERS = 8192
KS = (1, 2, 4, 8, 16)
CLASS_DESCRIPTIONS = ("a real photograph", "an AI-generated image")
CHECKPOINT_SHA256 = "b8cca3fd41ae0c99ba7e8951adf17d267cdb84cd88be6f7c2e0eca1737a03836"


def _json_sha(value):
    data = json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def _tensor_sha(value):
    value = value.detach().to(device="cpu", dtype=torch.float32).contiguous()
    digest = hashlib.sha256()
    digest.update(str(tuple(value.shape)).encode("ascii"))
    digest.update(b"torch.float32\0")
    digest.update(value.numpy().tobytes(order="C"))
    return digest.hexdigest()


def _path(row):
    value = row["path"]
    if not isinstance(value, str) or not value:
        raise ValueError("Each manifest image needs a nonempty relative path")
    path = PurePosixPath(value.replace("\\", "/"))
    if path.is_absolute() or ":" in value or ".." in path.parts:
        raise ValueError("Image path must remain relative to dataset_root")
    return path


def _safe_rows(rows):
    """Image-loader view: label and all other target metadata are excluded."""
    safe = []
    for row in rows:
        path = _path(row)
        parts = tuple(part.casefold() for part in path.parts)
        if (row.get("split") != "test" or not row.get("domain")
                or not (parts[0] == "diffusion_datasets"
                        or (len(parts) > 1 and parts[:2] == ("datasets", "test")))):
            raise ValueError("V2 query must be a named test domain, never source train/val")
        item = {"path": row["path"]}
        if "size" in row:
            if int(row["size"]) < 0:
                raise ValueError("Image size cannot be negative")
            item["size"] = int(row["size"])
        safe.append(item)
    # A physical path may reoccur in distinct targets, but never within a cell.
    if len({str(_path(row)).casefold() for row in safe}) != len(safe):
        raise ValueError("Duplicate query path within one target cell")
    return safe


def validate_support(support_rows, k, seed=100):
    """CPU-only exact-2K and physical ProGAN/train permission validation."""
    k, seed = int(k), int(seed)
    if k not in KS or seed != 100:
        raise ValueError("This approved first pass permits K1/2/4/8/16, seed100 only")
    rows = [dict(row) for row in support_rows]
    if len(rows) != 2*k or sorted(int(row["label"]) for row in rows) != [0]*k+[1]*k:
        raise ValueError("V2 source support must be exactly K real plus K fake")
    paths = []
    for row in rows:
        path = _path(row)
        if path.parts[0].casefold() != "progan_train":
            raise ValueError("Cross-generator V2 may read only physical progan_train supports")
        label_dirs = [part.casefold() for part in path.parts if part.casefold() in ("0_real", "1_fake")]
        if label_dirs != ["0_real" if int(row["label"]) == 0 else "1_fake"]:
            raise ValueError("ProGAN support path and label disagree")
        if row.get("split", "train") != "train":
            raise ValueError("Only the train split may supply V2 supervision")
        if row.get("source") != "ProGAN" or row.get("domain") != "ProGAN":
            raise ValueError("Source support must have source=domain=ProGAN")
        for field in ("generator", "family", "source_generator"):
            if field in row and str(row[field]).casefold() != "progan":
                raise ValueError(f"Support {field} must identify ProGAN")
        paths.append(str(path).casefold())
    if len(set(paths)) != len(paths):
        raise ValueError("Duplicate source support path")
    return rows


def normalized_config(config):
    """Return an expanded locked recipe; reject supplied scientific changes.

    Paths and fields match the original Engine's top-level config. Unknown
    top-level run/provenance fields survive
    for the runner, but do not change the imported scientific implementation.
    """
    cfg = dict(config)
    locked = {
        "epochs": 20, "batch_size": 1, "optimizer": "Adam",
        "learning_rate": 0.0002, "weight_decay": 0.0,
        "training_seed_base": 314159, "gradient_scaler_initial_scale": 1.0,
        "staged_layers": [1, 7, 13, 19],
        "class_descriptions": list(CLASS_DESCRIPTIONS),
        "checkpoint_sha256": CHECKPOINT_SHA256,
        "cache_fusion": False, "text_training": False,
        "query_fit_images": 0, "auxiliary_source_images": 0,
    }
    for key, expected in locked.items():
        if key in cfg and cfg[key] != expected:
            raise ValueError(f"UFD V2 locked configuration differs: {key}")
        cfg[key] = expected
    for key in ("dataset_root", "checkpoint", "clip_code_root"):
        if not cfg.get(key):
            raise ValueError(f"Missing V2 input: {key}")
    cfg.setdefault("inference_batch_size", 32)
    cfg.setdefault("query_workers", 4)
    if int(cfg["inference_batch_size"]) < 1 or int(cfg["query_workers"]) < 0:
        raise ValueError("Invalid inference batch or worker count")
    if cfg.get("checkpoint_rule", "final_epoch_no_validation_selection") not in (
            "final_epoch_no_validation_selection", "last_epoch_no_query_selection"):
        raise ValueError("V2 uses only the twentieth final epoch")
    return cfg


def recipe():
    """Expanded scientific specification suitable for a sealed config/audit."""
    return {
        "variant": VARIANT, "method": METHOD, "clip_model": "ViT-L/14",
        "clip_frozen": True, "clip_eval_during_support_training": True,
        "prompt_shape": [4, 2, 1024], "trainable_parameters": TRAINABLE_PARAMETERS,
        "prompt_initialization": "fresh_normal_mean0_std0.02",
        "staged_layers_one_based": [1, 7, 13, 19],
        "stage_transition": "replace_old_two_prompt_slots_keep_CLS_and_image_patch_states",
        "readout": "final_CLS_ln_post_visual_projection_L2_normalized",
        "fixed_text_encoder": "causal_attention_EOT_projection_L2_normalized",
        "fixed_class_descriptions": list(CLASS_DESCRIPTIONS),
        "temperature": "exp(frozen_CLIP.logit_scale)",
        "loss": "cross_entropy_on_same_two_class_logits",
        "optimizer": "Adam", "learning_rate": 0.0002, "weight_decay": 0.0,
        "optimizer_betas": [0.9, 0.999], "optimizer_eps": 1e-8,
        "epochs": 20, "batch_size": 1, "steps": "40*K",
        "lr_schedule": None, "gradient_clipping": None,
        "precision": "CLIP_native_FP16_learned_FP32_CUDA_autocast_FP16_GradScaler_init1",
        "training_seed": "314159+support_seed*100+K",
        "augmentation_seed": "training_seed+999",
        "order": "per_epoch_cpu_randperm_generator_seeded_training_seed",
        "train_transform": {
            "RandomResizedCrop": {"size": 224, "scale": [0.08, 1.0],
                                  "ratio": [0.75, 4/3], "interpolation": "bicubic",
                                  "antialias": True},
            "RandomHorizontalFlip": {"p": 0.5},
            "ToTensor": True,
            "Normalize": {"mean": [0.48145466, 0.4578275, 0.40821073],
                          "std": [0.26862954, 0.26130258, 0.27577711]},
        },
        "query_transform": "official_CLIP_resize224_bicubic_centercrop224_RGB_tensor_normalize",
        "checkpoint_rule": "last_epoch_no_query_selection",
        "raw_score": "raw_logits[:,1]-raw_logits[:,0]",
        "probabilities": "softmax_same_two_raw_logits_float32",
        "accuracy": "raw_score>0_fake_tie_real", "metric_score": "raw_score",
        "cache_fusion": False, "text_training": False, "query_fit_images": 0,
        "target_support_images": 0, "auxiliary_source_images": 0,
    }


def validate_source_payload(payload, config=None):
    """Validate final prompt-only payload and UFD source binding on the CPU."""
    if payload.get("variant") != VARIANT or payload.get("trainable_parameters") != TRAINABLE_PARAMETERS:
        raise ValueError("Not an 8192-parameter V2 staged2 state")
    if payload.get("checkpoint_sha256") != CHECKPOINT_SHA256:
        raise ValueError("State uses a different generic CLIP checkpoint")
    k, seed = int(payload["K"]), int(payload["support_seed"])
    support = validate_support(payload["support"], k, seed)
    if payload.get("final_epoch") != 20 or payload.get("steps") != 40*k:
        raise ValueError("Only the complete twentieth final epoch is loadable")
    if (payload.get("training_seed") != 314159+100*seed+k
            or payload.get("head_seed") != 314159+100*seed+k+271828):
        raise ValueError("Fresh source initialization seed does not match recipe")
    updates, skipped = payload.get("amp_optimizer_steps"), payload.get("amp_skipped_steps")
    if (not isinstance(updates, int) or not isinstance(skipped, int)
            or updates < 0 or skipped < 0 or updates+skipped != 40*k):
        raise ValueError("Invalid actual AMP optimizer-update accounting")
    state = payload.get("state", {})
    if set(state) != set(PARAMETER_SHAPES):
        raise ValueError("A V2 payload may contain only prompt_stages, no CLIP/head/cache weights")
    for name, shape in PARAMETER_SHAPES.items():
        value = state[name]
        if (not torch.is_tensor(value) or tuple(value.shape) != shape
                or value.dtype != torch.float32 or value.device.type != "cpu"
                or not bool(torch.isfinite(value).all())):
            raise ValueError(f"Invalid CPU FP32 final prompt tensor: {name}")
    binding = payload.get("ufd_v2", {})
    if (binding.get("schema_version") != 1 or binding.get("protocol") != "cross"
            or binding.get("source_generator") != "ProGAN"
            or binding.get("source_split") != "train"
            or binding.get("support_rows_sha256") != _json_sha(support)
            or binding.get("prompt_tensor_sha256") != _tensor_sha(state["prompt_stages"])
            or binding.get("recipe") != recipe()
            or binding.get("query_fit_images") != 0
            or binding.get("target_support_images") != 0
            or binding.get("fresh_prompt_initialization") is not True):
        raise ValueError("UFD final-state provenance binding is incomplete or changed")
    if config is not None:
        cfg = normalized_config(config)
        if binding.get("dataset_root") != str(Path(cfg["dataset_root"]).resolve()):
            raise ValueError("Payload belongs to another dataset root")
    return {"K": k, "support_seed": seed, "support_images": len(support),
            "prompt_tensor_sha256": binding["prompt_tensor_sha256"],
            "amp_update_review_required": skipped != 0}


class UFDV2Adapter:
    """Stateful source model; query calls do not change its learned state."""

    def __init__(self, config):
        self.cfg = normalized_config(config)
        self.engine = Engine(self.cfg)
        self.last_score_info = None
        self.last_train_info = None
        self.last_preflight_info = None

    def _permissions(self, rows, k, seed):
        support = validate_support(rows, k, seed)
        root = Path(self.cfg["dataset_root"]).resolve()
        for row in support:
            # Resolve only the actual 2K supports; do not enumerate/decode data.
            if not (root / row["path"]).resolve().is_relative_to(root):
                raise ValueError("Support path escapes the locked dataset root")
        return support

    def train_source(self, support_rows, k, seed=100, progress_callback=None):
        if self.cfg.get("performance_enabled") is False:
            raise ValueError("Performance training is disabled in this config")
        support = self._permissions(support_rows, int(k), int(seed))
        payload, info = self.engine.fit(VARIANT, support, int(k), int(seed), progress_callback)
        payload["ufd_v2"] = {
            "schema_version": 1, "protocol": "cross", "method": METHOD,
            "source_generator": "ProGAN", "source_split": "train",
            "dataset_root": str(Path(self.cfg["dataset_root"]).resolve()),
            "support_rows_sha256": _json_sha(support),
            "prompt_tensor_sha256": _tensor_sha(payload["state"]["prompt_stages"]),
            "fresh_prompt_initialization": True, "genimage_prompt_reuse": False,
            "target_support_images": 0, "query_fit_images": 0,
            "auxiliary_source_images": 0, "cache_fusion": False, "recipe": recipe(),
        }
        proof = validate_source_payload(payload, self.cfg)
        info.update({"method": METHOD, "protocol": "cross", "source_generator": "ProGAN",
                     "support_rows_sha256": payload["ufd_v2"]["support_rows_sha256"],
                     "prompt_tensor_sha256": proof["prompt_tensor_sha256"],
                     "amp_update_review_required": proof["amp_update_review_required"],
                     "query_labels_read": 0, "target_support_images": 0,
                     "auxiliary_source_images": 0, "cache_fusion": False,
                     "fresh_prompt_initialization": True})
        self.engine.loaded_payload = payload
        self.last_train_info = info
        return payload, info

    def load_source(self, payload):
        validate_source_payload(payload, self.cfg)
        self._permissions(payload["support"], payload["K"], payload["support_seed"])
        self.engine.load(payload)
        return self

    def preflight(self, support_rows, seed=100):
        """Two support updates plus synthetic parity/reload; no query reads."""
        k = len(support_rows)//2
        support = self._permissions(support_rows, k, int(seed))
        try:
            info = self.engine.preflight(VARIANT, support, int(seed))
        finally:
            # Even a failed diagnostic must not leave a scoreable partial model.
            self.engine.candidate = None
            self.engine.loaded_payload = None
        info.update({"method": METHOD, "protocol": "cross", "source_generator": "ProGAN",
                     "support_rows_sha256": _json_sha(support),
                     "query_labels_read": 0, "target_support_images": 0,
                     "recipe": recipe()})
        # The two-step diagnostic state must not become a production model.
        self.last_preflight_info = info
        return info

    def predict(self, query_rows, progress_callback=None):
        engine = self.engine
        if engine.candidate is None or engine.loaded_payload is None:
            raise RuntimeError("Train or load one final ProGAN source state before predicting")
        proof = validate_source_payload(engine.loaded_payload, self.cfg)
        if proof["amp_update_review_required"]:
            raise RuntimeError("Actual AMP skipped updates require review before query performance")
        rows = _safe_rows(query_rows)
        root = Path(self.cfg["dataset_root"]).resolve()
        for row in rows:
            if not (root / row["path"]).resolve().is_relative_to(root):
                raise ValueError("Query path escapes locked dataset root")
        candidate = engine.candidate
        candidate.eval()
        if engine.clip.training or any(p.requires_grad for p in engine.clip.parameters()):
            raise RuntimeError("CLIP must remain frozen and eval")
        before = _tensor_sha(candidate.learnable_state()["prompt_stages"])
        if before != proof["prompt_tensor_sha256"]:
            raise ValueError("In-memory prompts differ from the shared final source state")
        loader = DataLoader(_QueryImages(engine.root, rows, engine.preprocess),
                            batch_size=int(self.cfg["inference_batch_size"]), shuffle=False,
                            num_workers=int(self.cfg["query_workers"]), pin_memory=True,
                            drop_last=False)
        logits_batches, probability_batches = [], []
        count = 0
        torch.cuda.synchronize()
        started = time.perf_counter()
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.float16):
            for images in loader:
                logits, _ = candidate(images.to(engine.device, non_blocking=True), engine.fixed_text)
                logits = logits.float()
                probabilities = torch.softmax(logits, dim=1)
                values = logits.cpu().numpy().astype(np.float32, copy=False)
                probs = probabilities.cpu().numpy().astype(np.float32, copy=False)
                if values.ndim != 2 or values.shape[1] != 2 or not np.isfinite(values).all() or not np.isfinite(probs).all():
                    raise RuntimeError("Invalid V2 logits/probabilities")
                logits_batches.append(values)
                probability_batches.append(probs)
                count += len(values)
                if progress_callback is not None:
                    progress_callback({"stage": "query_forward_only", "method": METHOD,
                                       "query_completed": count, "query_total": len(rows),
                                       "elapsed_seconds": time.perf_counter()-started})
        torch.cuda.synchronize()
        elapsed = time.perf_counter()-started
        after = _tensor_sha(candidate.learnable_state()["prompt_stages"])
        if after != before or count != len(rows):
            raise RuntimeError("Query changed source prompts or omitted rows")
        logits = np.concatenate(logits_batches) if logits_batches else np.empty((0, 2), np.float32)
        probabilities = (np.concatenate(probability_batches) if probability_batches
                         else np.empty((0, 2), np.float32))
        raw_margin = (logits[:, 1]-logits[:, 0]).astype(np.float32, copy=False)
        self.last_score_info = {
            "method": METHOD, "variant": VARIANT, "query_images": count,
            "query_seconds": elapsed, "peak_cuda_memory_bytes": torch.cuda.max_memory_allocated(),
            "query_fit_images": 0, "query_labels_read": 0, "target_support_images": 0,
            "auxiliary_source_images": 0, "cache_fusion": False,
            "prompt_tensor_sha256_before": before, "prompt_tensor_sha256_after": after,
            "source_state_unchanged": True, "query_order_path_sha256": _json_sha([r["path"] for r in rows]),
            "score_formula": "logit_fake-logit_real", "probability_formula": "softmax_same_logits_float32",
            "independent_neural_replay_performed": False,
        }
        engine.last_score_info = self.last_score_info
        return {"paths": np.asarray([r["path"] for r in rows], dtype=np.str_),
                "raw_logits": logits, "raw_margin": raw_margin,
                "probabilities": probabilities, "info": dict(self.last_score_info)}


def load_model(config):
    return UFDV2Adapter(config)


def train_source(model, support_rows, k, seed=100, progress_callback=None):
    return model.train_source(support_rows, k, seed, progress_callback)


def load_source(model, payload):
    return model.load_source(payload)


def predict(model, query_rows, progress_callback=None):
    return model.predict(query_rows, progress_callback)
