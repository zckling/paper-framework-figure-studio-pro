"""Visual-only prompt candidates; frozen CLIP and no query-side updates.

This module deliberately does not import or alter any earlier sealed runner.
All intermediate L12 features are post-block-12 and pre-ln_post/projection.
"""
from __future__ import annotations

import math
from collections import OrderedDict

import torch
from torch import nn
from torch.nn import functional as F


VARIANTS = (
    "text8", "l12_head_frozen", "l12_head_prompt", "final_head_frozen",
    "final_head_prompt", "randomnorm8", "patchinit8", "anchor8", "shallow2",
    "staged2", "clspatch_frozen", "clspatch_prompt", "shallow4", "fixedmix4",
    "conditional4",
)
EXPECTED_PARAMETERS = {
    "text8": 8192, "l12_head_frozen": 2050, "l12_head_prompt": 10242,
    "final_head_frozen": 1538, "final_head_prompt": 9730,
    "patchinit8": 8192, "randomnorm8": 8192, "anchor8": 8192,
    "shallow2": 2048, "staged2": 8192, "clspatch_frozen": 4098,
    "clspatch_prompt": 12290, "shallow4": 4096, "fixedmix4": 8192,
    "conditional4": 9217,
}


def image_tokens(clip_model: nn.Module, images: torch.Tensor) -> torch.Tensor:
    """Original CLS/patch sequence after positional encoding and ln_pre."""
    vision = clip_model.visual
    x = vision.conv1(images.to(dtype=vision.conv1.weight.dtype))
    x = x.flatten(2).transpose(1, 2)
    cls = vision.class_embedding.to(x.dtype).expand(x.shape[0], 1, -1)
    x = torch.cat((cls, x), dim=1)
    return vision.ln_pre(x + vision.positional_embedding.to(x.dtype))


def frozen_final_feature(clip_model: nn.Module, images: torch.Tensor) -> torch.Tensor:
    x = image_tokens(clip_model, images).transpose(0, 1)
    for block in clip_model.visual.transformer.resblocks:
        x = block(x)
    x = clip_model.visual.ln_post(x[0])
    if clip_model.visual.proj is not None:
        x = x @ clip_model.visual.proj
    return F.normalize(x.float(), dim=-1)


class VisualCandidate(nn.Module):
    """Only prompt/head/router parameters train; CLIP remains eval and frozen."""

    def __init__(self, clip_model: nn.Module, variant: str, *, init_seed: int,
                 head_seed: int, staged_layers=(1, 7, 13, 19)):
        super().__init__()
        if variant not in VARIANTS:
            raise ValueError(f"Unknown visual candidate: {variant}")
        self.clip_model = clip_model
        self.variant = variant
        self.staged_layers = tuple(int(x) for x in staged_layers)
        if self.staged_layers != (1, 7, 13, 19):
            raise ValueError("Staged prompt positions must be [1, 7, 13, 19]")
        width = clip_model.visual.conv1.out_channels
        if width != 1024 or len(clip_model.visual.transformer.resblocks) != 24:
            raise ValueError("Candidates require the sealed ViT-L/14 1024-wide 24-block model")
        self.prompt = None
        self.prompt_stages = None
        self.prompt_bases = None
        self.router = None
        self.last_route = None
        self.head = None
        self.has_prompt = not variant.endswith("_frozen")
        self.readout = ("clspatch" if variant.startswith("clspatch") else
                        "l12" if variant.startswith("l12_head") else "final")
        self.prompt_count = (0 if not self.has_prompt else 2 if variant in
                             ("shallow2", "staged2") else 4 if variant in
                             ("shallow4", "fixedmix4", "conditional4") else 8)
        # Forking the RNG makes head initialization and data augmentation independent
        # of the number or shape of prompt parameters in each candidate.
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(init_seed)
            if variant == "staged2":
                self.prompt_stages = nn.Parameter(torch.empty(4, 2, width).normal_(std=0.02))
            elif variant in ("fixedmix4", "conditional4"):
                self.prompt_bases = nn.Parameter(torch.empty(2, 4, width).normal_(std=0.02))
                if variant == "conditional4":
                    self.router = nn.Linear(width, 1, dtype=torch.float32)
            elif self.has_prompt:
                self.prompt = nn.Parameter(torch.empty(self.prompt_count, width).normal_(std=0.02))
        if "head" in variant or variant.startswith("clspatch"):
            dimension = 2048 if self.readout == "clspatch" else 1024 if self.readout == "l12" else 768
            with torch.random.fork_rng(devices=[]):
                torch.manual_seed(head_seed)
                self.head = nn.Linear(dimension, 2, dtype=torch.float32)
        clip_model.eval().requires_grad_(False)
        if self.trainable_parameter_count() != EXPECTED_PARAMETERS[variant]:
            raise ValueError(f"Unexpected trainable parameter count for {variant}")

    def train(self, mode=True):
        super().train(mode)
        self.clip_model.eval()
        return self

    def trainable_named_parameters(self):
        return OrderedDict((n, p) for n, p in self.named_parameters() if p.requires_grad)

    def trainable_parameter_count(self):
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def learnable_state(self):
        return {name: parameter.detach().float().cpu().clone()
                for name, parameter in self.trainable_named_parameters().items()}

    def load_learnable_state(self, state):
        params = self.trainable_named_parameters()
        if set(params) != set(state):
            raise ValueError("Learnable-state names do not match the candidate")
        with torch.no_grad():
            for name, parameter in params.items():
                value = state[name]
                if not torch.is_tensor(value) or value.shape != parameter.shape or not torch.isfinite(value).all():
                    raise ValueError(f"Invalid learned parameter: {name}")
                parameter.copy_(value.to(device=parameter.device, dtype=torch.float32))

    def _context(self, original_tokens):
        if self.prompt_bases is not None:
            if self.router is None:
                a = original_tokens.new_full((original_tokens.shape[0], 1, 1), 0.5)
            else:
                condition = F.normalize(original_tokens[:, 1:].float().mean(dim=1), dim=-1).detach()
                a = self.router(condition).float().sigmoid().unsqueeze(-1)
                self.last_route = a.detach().flatten()
            return (a * self.prompt_bases[0] + (1-a) * self.prompt_bases[1]).to(original_tokens.dtype)
        return self.prompt.to(original_tokens.dtype).unsqueeze(0).expand(original_tokens.shape[0], -1, -1)

    def features(self, images: torch.Tensor, *, use_prompt=True) -> torch.Tensor:
        original = image_tokens(self.clip_model, images)
        active = bool(use_prompt and self.has_prompt)
        n_prompt = self.prompt_count if active else 0
        if active and self.prompt_stages is None:
            context = self._context(original)
            x = torch.cat((original[:, :1], context, original[:, 1:]), dim=1)
        else:
            x = original
        x = x.transpose(0, 1)
        stage_number = 0
        for block_number, block in enumerate(self.clip_model.visual.transformer.resblocks, start=1):
            if active and self.prompt_stages is not None and block_number in self.staged_layers:
                if stage_number:
                    x = torch.cat((x[:1], x[1+n_prompt:]), dim=0)
                context = self.prompt_stages[stage_number].to(x.dtype).unsqueeze(1).expand(-1, x.shape[1], -1)
                x = torch.cat((x[:1], context, x[1:]), dim=0)
                stage_number += 1
            x = block(x)
            if self.readout in ("l12", "clspatch") and block_number == 12:
                cls = F.normalize(x[0].float(), dim=-1)
                if self.readout == "clspatch":
                    patch = x[1+n_prompt:]
                    if patch.shape[0] != 256:
                        raise ValueError("Patch readout must exclude CLS and every prompt slot")
                    patch_mean = F.normalize(patch.float().mean(dim=0), dim=-1)
                    return torch.cat((cls, patch_mean), dim=-1) / math.sqrt(2.0)
                return cls
        x = self.clip_model.visual.ln_post(x[0])
        if self.clip_model.visual.proj is not None:
            x = x @ self.clip_model.visual.proj
        return F.normalize(x.float(), dim=-1)

    def forward(self, images: torch.Tensor, fixed_text: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        # A frozen-feature head needs no CLIP graph, while prompted heads require
        # gradients through the frozen operations back into prompt parameters.
        if not self.has_prompt:
            with torch.no_grad():
                features = self.features(images)
        else:
            features = self.features(images)
        if self.head is not None:
            logits = self.head(features.float()).float()
        else:
            logits = self.clip_model.logit_scale.exp().float() * (features.float() @ fixed_text.float().T)
        return logits, features


def spherical_patch_initialization(patches: torch.Tensor, *, seed: int,
                                   iterations=20, clusters=8, target_norm=0.64):
    """Deterministic support-only CPU spherical k-means with farthest starts."""
    data = patches.detach().float().cpu()
    if data.ndim != 2 or data.shape[1] != 1024 or len(data) < clusters or not torch.isfinite(data).all():
        raise ValueError("Invalid support patch vectors")
    if torch.any(data.norm(dim=1) <= 1e-12):
        raise ValueError("Degenerate support patch vector")
    data = F.normalize(data, dim=-1)
    generator = torch.Generator(device="cpu").manual_seed(seed)
    first = int(torch.randint(len(data), (1,), generator=generator))
    ids = [first]
    best_similarity = data @ data[first]
    for _ in range(1, clusters):
        chosen = int(torch.argmin(best_similarity))
        ids.append(chosen)
        best_similarity = torch.maximum(best_similarity, data @ data[chosen])
    centers = data[ids].clone()
    actual_iterations = 0
    old_assignment = None
    for iteration in range(iterations):
        assignment = (data @ centers.T).argmax(dim=1)
        actual_iterations = iteration + 1
        if old_assignment is not None and torch.equal(assignment, old_assignment):
            break
        old_assignment = assignment.clone()
        for index in range(clusters):
            members = data[assignment == index]
            if len(members):
                mean = members.mean(dim=0)
                if mean.norm() > 1e-12:
                    centers[index] = F.normalize(mean, dim=0)
    return centers * float(target_norm), {
        "rule": "support_post_pos_lnpre_patch_vectors_cpu_spherical_kmeans_farthest_start",
        "patch_vectors": len(data), "clusters": clusters, "maximum_iterations": iterations,
        "actual_iterations": actual_iterations, "initial_center_indices": ids,
        "target_token_norm": float(target_norm), "cluster_seed": seed,
        "query_images_used": 0,
    }
