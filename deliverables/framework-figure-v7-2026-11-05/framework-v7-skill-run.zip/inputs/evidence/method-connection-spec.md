# 方法事实与连线规范

以下是基于本地论文方法原文及实现核对的绘图事实。用户要求的是纠正表达，不是改动检测算法。

## 共享输入与训练/推断

- 唯一一批源域支持集：`S = {(x_i, y_i)}_{i=1}^{2K}`，K 张 real 与 K 张 fake，标签 real=0、fake=1。两个方法使用完全相同的图像身份；组合不额外增加标签预算。
- 原型分支：support 通过冻结 CLIP 的第 12 个 block 读取 CLS，保存支持特征与全局中心。没有任务训练参数。
- 视觉提示分支：同一 support 的图像通过带提示的编码器，与固定文本特征形成 logits；support 标签提供交叉熵损失，只更新提示向量。原型分支的加权结果不作为这一分支的训练输入。
- 查询推断：同一 query 分别走未加提示的中间层路径及训练后带提示的完整路径。提示参数在推断阶段不更新，query 标签不参与训练。

因而下列结构均应表达出来：

```text
Shared support images + labels
  ├─ frozen block-12 encoding → cached support features / global means
  └─ prompted visual encoding + fixed text logits + support-label CE
                                  → fitted prompt parameters

Query image
  ├─ frozen block-12 encoding → query-conditioned prototype score → p_p
  └─ prompted blocks 1–24 with fitted prompts → fixed-text margin → p_v

prediction = (p_p + p_v) / 2
```

**不要为满足“显示共享 support”而删除 Stage-wise 的 query 推断箭头；也不要从 query 向提示训练/损失画梯度更新箭头。** 若将训练过程画成摘要块，明确它是训练操作，指向提示参数的连线是学得参数的依赖；不能让读者误认为 support 图像直接变成四组提示 token，而没有视觉编码及监督优化。

## Query-Conditioned Prototype Mixing

- 骨干：CLIP ViT-L/14；读取 block 12 后、最终归一化和投影前的 1,024-D CLS，并 L2 归一化。
- 类内全局中心：`μ_c = norm(mean_i z_ci)`。
- 查询相关权重：`α_ci(q) = softmax_i(15 qᵀ z_ci)`，真假两类分别归一化。
- 局部支持向量：`m_c(q) = Σ_i α_ci(q) z_ci`，混合之前不再次归一化。
- 类别方向：`μ̃_c(q) = norm(0.5 μ_c + 0.5 m_c(q))`。
- 分数：`s_p = 15 qᵀ(μ̃_1(q) − μ̃_0(q))`；`p_p = sigmoid(s_p)`。
- 特殊情况 K=1 与静态原型逐值相同。不要添加可学习混合权重或额外分类头。

## Stage-wise Visual Prompting

- 冻结视觉主干与文本编码器；24 个 blocks 分为 1–6、7–12、13–18、19–24。
- 在 blocks 1、7、13、19 前各插入 2 个 1,024-D 可训练 tokens，共 `4 × 2 × 1024 = 8,192` 参数。
- 后续阶段用新的两枚提示替换旧提示槽位，同时保留 CLS 与图像 tokens；不是持续累积成八个同时存在的提示。
- 第一组在位置嵌入和输入层归一化之后插入；最终 CLS 经投影形成 768-D 归一化图像特征 `v(x)`。
- 固定文本完整描述为 `a real photograph` 与 `an AI-generated image`；图中可简写 real / fake，但不能暗示文本被训练。
- 训练 logits 为 `ℓ_ic = S v(x_i)ᵀt_c`，S 为冻结的 CLIP logit scale，约 100；只对支持标签计算 CE 并更新提示参数。
- 推断时原生 logit margin 为 `s_v = S v(x)ᵀ(t_1−t_0)`，融合概率 `p_v = sigmoid(15 s_v / S)`，等价于 `sigmoid(15 v(x)ᵀ(t_1−t_0))`。
- 不要把图中的原生尺度约 100 与融合前固定尺度 15 混淆。

## 融合与图形语义

- 固定概率平均 `p = (p_p + p_v) / 2`。`p > 0.5` 判 fake，否则 real。
- 两分支需要不同的视觉激活，不能画成一次共同视觉前向后简单共用所有激活。
- 蓝色圆点=真实类支持特征；绿色方块=伪造类支持特征；青色雪花=冻结；黄色小 token=可训练提示。
- v3 黑色实线=图像/特征前向；棕色虚线=支持训练与已学习提示参数依赖。此配色可优化，但线型含义必须唯一且有说明。
- 两线交叉但无连接时应断开或绕行，不要误画交点。分叉要从共享 support 的同一源头开始，而不是复制成两批看似不同的 support。

## 依据定位

- `evidence/方法原文摘录.md`：原文 51 行整体关系、55 行仅 support 参与优化、91–105 行提示结构及支持集交叉熵、119–125 行固定融合。
- `evidence/src/visual_prompt_candidates.py`：`prompt_stages` 为 `(4, 2, width)`；`features()` 在指定 block 替换旧提示槽。
- `evidence/src/visual_prompt_candidate_engine.py`：`_fit()` 读取 support、计算 `F.cross_entropy`；`fit()` 与 `score()` 分开，后者在 `torch.inference_mode()` 下处理 query。
- `evidence/src/ufd_v2_adapter.py`：`recipe()` 说明训练与推断约束，`query_fit_images=0`；`predict()` 检查预测前后提示状态保持不变。

以上源码仅作只读依据，交接包不提供全部项目依赖，不要为了看图而导入执行训练模块。
