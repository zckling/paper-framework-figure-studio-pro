# F01 scientific connectivity edit 1

Input raster: inputs/generation-history/F01-draft.png (original image_gen exec-ab72ad03-3f63-441c-a76a-748f2ccd55e6.png).

Preserve layout and correct these local points: direct support-image black input into training CLIP instead of P; keep P orange input separate; draw fixed-text→native-logits arrow; gradient starts at CE with no arrowhead into CE and propagates through frozen backbone back to P; compact Save P* state beside optimized P matching local Load P*; both μ and m inputs to each class Mix have0.5 coefficients; source set script𝒮 distinct from nativeS (omit source-set symbol if script unsupported); CLS/image slots neutral gray.
