# F01 scientific connectivity edit 2

Input raster: inputs/generation-history/F01-edit1.png (original image_gen exec-4fca205f-9f09-4dc7-bd1b-e5b209495ec4.png).

Preserve full figure. For EACH b class row erase duplicated parallel m→Mix arrows and redraw exactly ONE horizontal m→Mix input labeled0.5, plus exactly ONE separate top μ→Mix input labeled0.5. No duplicate m inputs. Keep post-Mix L2norm. Add tiny dashed gradient continuation from training CLIP left edge back to P right edge, below solid forward P→CLIP, to show gradient reaches P. In c change blue CLS slot to neutral gray. Remove plain source-set S if script symbol unsupported, without changing native scalarS. No other edits or crop.
