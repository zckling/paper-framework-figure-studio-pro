# Current author review: v8, one selected figure
Preserve the overview plus two mechanism panel structure of the v7 editable figure.
1. Prototype query output must explicitly show CLS→L2normalize then q1024. q and z use unprompted block12 CLS before final ln_post/projection; normalize in FP32.
2. Label labeled SOURCE support calligraphic𝒮, query x in unseen-generator evaluation, no query-time parameter updates. Query includes real images and fakes from unseen generators. Same source cache and fitted prompts reused for all target queries; query labels never adaptation.
3. Cache separates stored support features {z_ci} from class prototypes μ_c; caption μ_c=norm(mean_i z_ci). μ not CE-learned, not a separate static classifier.
4. P has four groups, two1024D tokens each, jointly fitted. Show four groups·2tokens/stage and8192parameters optimized on support once. Trainable P during fit, Fixed P* during inference.
5. Replace floating big fitted-state card by compact Save P* near optimized P state; local Load P* uses same state symbol. No long load rail.
6. b weighting labels α_ci near variable-width q-support connections; within-class softmax_i; weighted supports visibly converge to sum; m not normalized before mixing.
7. c uses stage overview and exactly ONE boundary detail. Highlight one boundary and link with neutral line without arrow. Delete repeated large keep/discard/insert sentence, duplicate discard markers, repeated parameter count.
8. Readout compact two lines: CLIP CLS readout /768-D·normalized; caption full CLS→ln_post→projection→L2 norm.
9. Main probabilities p_P(x),p_V(x); q=f12(x) normalized. β weighting,γ score, fixedβ=γ=15; native support CE S=exp(logit_scale). Explicit visual score difference v^Tt1−v^Tt0; final p>0.5 fake, otherwise real.
10. Target at180mm: major labels8–10pt, auxiliary≥7pt. Delete duplicate text and move definitions to caption. One concise gradient label: Gradients through frozen backbone; update P only.
This is direct revision of a selected single figure, not a request to explore two new layouts. Inherited user authorization includes editable SVG/Visio delivery and publishing to the same GitHub repository branch. Vector companion is authored separately from image_gen reference rendering, no claim of exact raster decomposition.
